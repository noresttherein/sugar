#if ((${PACKAGE_NAME} && ${PACKAGE_NAME} != ""))package ${PACKAGE_NAME} #end
#parse("Scala Class Header.scala")
class ${NAME}(msg :String, cause :Throwable) extends#if ((${BASE_EXCEPTION} && ${BASE_EXCEPTION != "")) ${BASE_EXCEPTION}#else RuntimeException#end (msg, cause) {
    
    def this(msg :String) = this(msg, null)
    
    def this(cause :Throwable) = this(cause.getMessage, cause)
    
    def this() = this("", null)
}
