#if ((${PACKAGE_QUALIFIER} && ${PACKAGE_QUALIFIER} != ""))package ${PACKAGE_QUALIFIER} #end
#parse("Scala Class Header.scala")
package object ${PACKAGE_SIMPLE_NAME} {

}
