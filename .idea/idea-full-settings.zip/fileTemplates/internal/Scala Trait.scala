#if ((${PACKAGE_NAME} && ${PACKAGE_NAME} != ""))package ${PACKAGE_NAME} #end
#parse("Scala Class Header.scala")
trait ${NAME} {

}
